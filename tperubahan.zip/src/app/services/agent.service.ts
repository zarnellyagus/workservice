import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';

import {
  Agent,
  AgentSearchParams
} from '../models/agent.model';

@Injectable({
  providedIn: 'root'
})
export class AgentService {
  private http = inject(HttpClient);

  private readonly baseUrl = 'https://localhost:7201/api/agents';

  getAgent(
    companyID: string,
    agentID: string,
    policyID = ''
  ): Observable<Agent> {
    let params = new HttpParams()
      .set('companyID', companyID)
      .set('agentID', agentID);

    if (policyID.trim()) {
      params = params.set('policyID', policyID.trim());
    }

    return this.http.get<Agent>(
      `${this.baseUrl}/detail`,
      { params }
    );
  }

  searchAgents(
    paramsValue: AgentSearchParams
  ): Observable<Agent[]> {
    let params = new HttpParams()
      .set('companyID', paramsValue.companyID);

    if (paramsValue.policyID?.trim()) {
      params = params.set(
        'policyID',
        paramsValue.policyID.trim()
      );
    }

    if (paramsValue.agentID?.trim()) {
      params = params.set(
        'agentID',
        paramsValue.agentID.trim()
      );
    }

    if (paramsValue.agentName?.trim()) {
      params = params.set(
        'agentName',
        paramsValue.agentName.trim()
      );
    }

    return this.http.get<Agent[]>(
      `${this.baseUrl}/search`,
      { params }
    );
  }
}