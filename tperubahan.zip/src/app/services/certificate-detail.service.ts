import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';
import {
  Observable,
  map
} from 'rxjs';

import {
  ActivityHistoryItem,
  AgentDetailApiResponse,
  AgentInfo,
  AgentSearchApiResponse,
  CertificateDetailResponse,
  ClientInfo,
  ClientSearchResult,
  CoverageDocumentInfo,
  HealthQuestionInfo,
  LetterItem,
  PolicyHistoryItem,
  PolicyOption,
  ProductAppliedItem,
  ProductPackageOption
} from '../models/certificate-detail.model';

@Injectable({
  providedIn: 'root'
})
export class CertificateDetailService {
  private readonly http = inject(HttpClient);

  private readonly certificateBaseUrl =
    'https://localhost:7201/api/certificate';

  private readonly agentBaseUrl =
    'https://localhost:7201/api/agents';

  // ============================================================
  // CERTIFICATE DETAIL
  // ============================================================

  getDetail(
    certificateID: string
  ): Observable<CertificateDetailResponse> {
    return this.http.get<CertificateDetailResponse>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(certificateID)
      }/detail`
    );
  }

  // ============================================================
  // CLIENT DETAIL
  // ============================================================

  getClientInfo(
    clientID: string
  ): Observable<ClientInfo> {
    return this.http.get<ClientInfo>(
      `${this.certificateBaseUrl}/client/${
        encodeURIComponent(clientID)
      }`
    );
  }

  // ============================================================
  // CLIENT SEARCH
  // ============================================================

  searchClients(
    companyID?: string,
    clientName?: string,
    clientID?: string,
    alternateID?: string
  ): Observable<ClientSearchResult[]> {
    let params = new HttpParams();

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (clientName?.trim()) {
      params = params.set(
        'clientName',
        clientName.trim()
      );
    }

    if (clientID?.trim()) {
      params = params.set(
        'clientID',
        clientID.trim()
      );
    }

    if (alternateID?.trim()) {
      params = params.set(
        'alternateID',
        alternateID.trim()
      );
    }

    return this.http.get<ClientSearchResult[]>(
      `${this.certificateBaseUrl}/client-search`,
      { params }
    );
  }

  // ============================================================
  // AGENT DETAIL
  // ============================================================

  getAgentInfo(
    agentID: string,
    companyID?: string,
    policyID?: string
  ): Observable<AgentInfo> {
    let params = new HttpParams()
      .set(
        'agentID',
        agentID.trim()
      );

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (policyID?.trim()) {
      params = params.set(
        'policyID',
        policyID.trim()
      );
    }

    return this.http.get<AgentDetailApiResponse>(
      `${this.agentBaseUrl}/detail`,
      { params }
    ).pipe(
      map(response => {
        if (!response.success || !response.data) {
          throw new Error(
            response.message ||
            'Agent not found.'
          );
        }

        return response.data;
      })
    );
  }

  // ============================================================
  // AGENT SEARCH
  // ============================================================

  searchAgents(
    companyID?: string,
    policyID?: string,
    agentID?: string,
    agentName?: string,
    page = 1,
    pageSize = 20
  ): Observable<AgentSearchApiResponse> {
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize);

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (policyID?.trim()) {
      params = params.set(
        'policyID',
        policyID.trim()
      );
    }

    if (agentID?.trim()) {
      params = params.set(
        'agentID',
        agentID.trim()
      );
    }

    if (agentName?.trim()) {
      params = params.set(
        'agentName',
        agentName.trim()
      );
    }

    return this.http.get<AgentSearchApiResponse>(
      `${this.agentBaseUrl}/search`,
      { params }
    );
  }

  // ============================================================
  // POLICY OPTIONS
  // ============================================================

  getPolicyOptions(
    companyID?: string
  ): Observable<PolicyOption[]> {
    let params = new HttpParams();

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    return this.http.get<PolicyOption[]>(
      `${this.certificateBaseUrl}/policy-options`,
      { params }
    );
  }

  // ============================================================
  // PRODUCT PACKAGE
  // ============================================================

  getProductPackageOptions(
    companyID?: string,
    productPackageID?: string
  ): Observable<ProductPackageOption[]> {
    let params = new HttpParams();

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (productPackageID?.trim()) {
      params = params.set(
        'productPackageID',
        productPackageID.trim()
      );
    }

    return this.http.get<ProductPackageOption[]>(
      `${this.certificateBaseUrl}/product-package`,
      { params }
    );
  }

  // ============================================================
  // COVERAGE DOCUMENT
  // ============================================================

  getCoverageDocument(
    memberID: string,
    companyID?: string,
    productPackageID?: string
  ): Observable<CoverageDocumentInfo[]> {
    let params = new HttpParams();

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (productPackageID?.trim()) {
      params = params.set(
        'productPackageID',
        productPackageID.trim()
      );
    }

    return this.http.get<CoverageDocumentInfo[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/coverage-document`,
      { params }
    );
  }

  // ============================================================
  // FINANCIAL HEALTH
  // ============================================================

  getFinancialHealth(
    memberID: string,
    companyID?: string,
    productID?: string,
    policyID?: string
  ): Observable<HealthQuestionInfo[]> {
    let params = new HttpParams();

    if (companyID?.trim()) {
      params = params.set(
        'companyID',
        companyID.trim()
      );
    }

    if (productID?.trim()) {
      params = params.set(
        'productID',
        productID.trim()
      );
    }

    if (policyID?.trim()) {
      params = params.set(
        'policyID',
        policyID.trim()
      );
    }

    return this.http.get<HealthQuestionInfo[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/financial-health`,
      { params }
    );
  }

  // ============================================================
  // POLICY HISTORY - PRODUCT APPLIED
  // ============================================================

  getProductApplied(
    memberID: string
  ): Observable<ProductAppliedItem[]> {
    return this.http.get<ProductAppliedItem[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/policy-history/product-applied`
    );
  }

  // ============================================================
  // POLICY HISTORY
  // ============================================================

  getPolicyHistory(
    memberID: string
  ): Observable<PolicyHistoryItem[]> {
    return this.http.get<PolicyHistoryItem[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/policy-history`
    );
  }

  // ============================================================
  // LETTERS
  // ============================================================

  getLetters(
    memberID: string
  ): Observable<LetterItem[]> {
    return this.http.get<LetterItem[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/letters`
    );
  }

  // ============================================================
  // ACTIVITY HISTORY
  // ============================================================

  getActivityHistory(
    memberID: string
  ): Observable<ActivityHistoryItem[]> {
    return this.http.get<ActivityHistoryItem[]>(
      `${this.certificateBaseUrl}/${
        encodeURIComponent(memberID)
      }/activity-history`
    );
  }
}