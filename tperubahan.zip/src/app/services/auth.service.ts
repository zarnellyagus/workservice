import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { LoginRequest, LoginResponse, Company, UserProfile } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly baseUrl = 'https://localhost:7201/api/auth';

  login(userID: string, companyID?: string): Observable<LoginResponse> {
    const req: LoginRequest = {
      userID,
      companyID: companyID || this.getSelectedCompanyID() || '01'
    };

    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, req).pipe(
      tap(res => {
        if (res.success) {
          sessionStorage.setItem('token', res.token ?? '');
          sessionStorage.setItem('userID', res.userID ?? '');
          sessionStorage.setItem('companyID', res.companyID ?? '');
          sessionStorage.setItem('companyName', res.companyName ?? '');
          sessionStorage.setItem('expiresAt', res.expiresAt ?? '');
          this.router.navigate(['/dashboard']);
        }
      }),
      catchError(err => {
        const msg = err?.error?.message || 'Login gagal. Periksa User ID dan Company.';
        return throwError(() => new Error(msg));
      })
    );
  }

  getCompanies(): Observable<Company[]> {
    return this.http.get<Company[]>(`${this.baseUrl}/companies`);
  }

  getProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.baseUrl}/profile`, {
      headers: this.getAuthHeaders()
    });
  }

  validateToken(): Observable<{ valid: boolean }> {
    return this.http.get<{ valid: boolean }>(`${this.baseUrl}/validate`, {
      headers: this.getAuthHeaders()
    });
  }

  isAuthenticated(): boolean {
    const token = sessionStorage.getItem('token');
    const expiresAt = sessionStorage.getItem('expiresAt');

    if (!token || !expiresAt) return false;

    const isValid = new Date(expiresAt) > new Date();
    if (!isValid) {
      this.clearSession();
    }

    return isValid;
  }

  getToken(): string | null {
    return sessionStorage.getItem('token');
  }

  getUserID(): string {
    return sessionStorage.getItem('userID') ?? '';
  }

  getCompanyID(): string {
    return sessionStorage.getItem('companyID') ?? '';
  }

  getCompanyName(): string {
    return sessionStorage.getItem('companyName') ?? '';
  }

  getSelectedCompanyID(): string {
    return sessionStorage.getItem('companyID') ?? '';
  }

  setSelectedCompanyID(companyID: string): void {
    sessionStorage.setItem('companyID', companyID);
  }

  getCurrentUser() {
    return {
      name: this.getUserID(),
      email: `${this.getUserID()}@${this.getCompanyID()}.com`.toLowerCase(),
      company: this.getCompanyName(),
      avatar: 'account_circle'
    };
  }

  logout(): void {
    this.clearSession();
    this.router.navigate(['/login']);
  }

  loginWithAzureSSO(): void {
    console.warn('Azure SSO not configured. Use manual login.');
    this.router.navigate(['/login'], { queryParams: { error: 'sso_failed' } });
  }

  private getAuthHeaders(): HttpHeaders {
    const token = this.getToken();
    return new HttpHeaders({
      Authorization: `Bearer ${token ?? ''}`
    });
  }

  private clearSession(): void {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('userID');
    sessionStorage.removeItem('companyID');
    sessionStorage.removeItem('companyName');
    sessionStorage.removeItem('expiresAt');
  }
}