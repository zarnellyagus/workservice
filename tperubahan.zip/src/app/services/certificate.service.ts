import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';

import { Observable } from 'rxjs';

import {
  Certificate,
  CertificateFilter,
  PagedResult
} from '../models/certificate.model';

import {
  PolicyOption
} from '../models/certificate-detail.model';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CertificateService {
  private readonly http = inject(HttpClient);

  private readonly base =
    `${environment.apiUrl}/api/certificate`;

  /**
   * GET /api/certificate
   */
  getList(
    filter: CertificateFilter
  ): Observable<PagedResult<Certificate>> {
    let params = new HttpParams()
      .set('pageNumber', String(filter.pageNumber))
      .set('pageSize', String(filter.pageSize))
      .set('sortColumn', filter.sortColumn)
      .set('sortDirection', filter.sortDirection);

    if (filter.memberID) {
      params = params.set(
        'memberID',
        filter.memberID
      );
    }

    if (filter.companyID) {
      params = params.set(
        'companyID',
        filter.companyID
      );
    }

    if (filter.policyID) {
      params = params.set(
        'policyID',
        filter.policyID
      );
    }

    if (filter.certificateID) {
      params = params.set(
        'certificateID',
        filter.certificateID
      );
    }

    if (filter.certificateStatus) {
      params = params.set(
        'certificateStatus',
        filter.certificateStatus
      );
    }

    if (filter.insuredName) {
      params = params.set(
        'insuredName',
        filter.insuredName
      );
    }

    return this.http.get<PagedResult<Certificate>>(
      this.base,
      { params }
    );
  }

  /**
   * GET /api/certificate/policy-options
   */
  getPolicyOptions(
    companyID: string
  ): Observable<PolicyOption[]> {
    const params = new HttpParams()
      .set('companyID', companyID);

    return this.http.get<PolicyOption[]>(
      `${this.base}/policy-options`,
      { params }
    );
  }

  /**
   * POST /api/certificate/search
   */
  search(
    filter: CertificateFilter
  ): Observable<PagedResult<Certificate>> {
    return this.http.post<PagedResult<Certificate>>(
      `${this.base}/search`,
      filter
    );
  }

  /**
   * GET /api/certificate/{memberId}?companyId=...
   */
  getByMemberId(
    memberId: string,
    companyId: string
  ): Observable<Certificate> {
    const params = new HttpParams()
      .set('companyId', companyId);

    return this.http.get<Certificate>(
      `${this.base}/${encodeURIComponent(memberId)}`,
      { params }
    );
  }
}