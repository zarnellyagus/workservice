export interface LoginRequest {
  userID:  string;
 
  companyID: string;
}

export interface LoginResponse {
  success:     boolean;
  message:     string;
  token:       string;
  userID:      string;
  companyID:   string;
  companyName: string;
  expiresAt:   string;
}

export interface Company {
  companyID:   string;
  companyName: string;
}

export interface UserProfile {
  userID:      string;
  companyID:   string;
  companyName: string;
  displayName: string;
  email:       string;
}