export interface CodeOption {
  codeID: string;
  codeName: string;
  codeSequence: number;
}