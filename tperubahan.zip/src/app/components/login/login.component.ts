import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../services/auth.service';
import { Company } from '../../models/auth.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, MatIconModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private authService = inject(AuthService);
  private router      = inject(Router);
  private route       = inject(ActivatedRoute);
  private fb          = inject(FormBuilder);

  loginForm!: FormGroup;
  isLoading    = false;
  errorMessage = '';
  activeTab: 'login' | 'register' = 'login';
  ssoFailed    = false;
  currentYear  = new Date().getFullYear();

  companies: Company[] = [];
  companiesLoading     = false;

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['error']) {
        this.ssoFailed = true;
        switch (params['error']) {
          case 'sso_failed':
            this.errorMessage = 'SSO authentication failed. Please use manual login.'; break;
          case 'invalid_sso_response':
            this.errorMessage = 'Invalid SSO response. Please use manual login.'; break;
          case 'sso_redirect_failed':
            this.errorMessage = 'Failed to connect to SSO. Please use manual login.'; break;
        }
      }
    });

    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/dashboard']);
      return;
    }

    this.initializeForm();
    this.loadCompanies();
  }

  initializeForm(): void {
    this.loginForm = this.fb.group({
      username:  ['', [Validators.required, Validators.minLength(3)]],
      // ❌ password dihapus dari form
      companyID: ['', Validators.required]
    });
  }

  loadCompanies(): void {
    this.companiesLoading = true;
    this.authService.getCompanies().subscribe({
      next: (list) => {
        this.companies        = list;
        this.companiesLoading = false;
        if (list.length === 1) {
          this.loginForm.get('companyID')?.setValue(list[0].companyID);
        }
      },
      error: () => {
        this.companiesLoading = false;
        this.companies = [];
      }
    });
  }

  switchTab(tab: 'login' | 'register'): void {
    this.activeTab    = tab;
    this.errorMessage = '';
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.markFormGroupTouched(this.loginForm);
      return;
    }

    this.isLoading    = true;
    this.errorMessage = '';

    const { username, companyID } = this.loginForm.value;

    // ← password tidak dikirim, backend pakai default
    this.authService.login(username, companyID).subscribe({
      next: () => { this.isLoading = false; },
      error: (error) => {
        this.isLoading    = false;
        this.errorMessage = error.message || 'Login failed. Please check your credentials.';
      }
    });
  }

  loginWithAzureSSO(): void {
    this.isLoading    = true;
    this.errorMessage = '';
    this.ssoFailed    = false;
    setTimeout(() => this.authService.loginWithAzureSSO(), 300);
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      formGroup.get(key)?.markAsTouched();
    });
  }

  getErrorMessage(fieldName: string): string {
    const control = this.loginForm.get(fieldName);
    const label   = fieldName === 'companyID' ? 'Company'
                  : fieldName.charAt(0).toUpperCase() + fieldName.slice(1);
    if (control?.hasError('required'))  return `${label} is required`;
    if (control?.hasError('minlength')) {
      const len = control.errors?.['minlength'].requiredLength;
      return `${label} must be at least ${len} characters`;
    }
    return '';
  }
}