import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule
} from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AgentService } from '../../services/agent.service';
import { Agent } from '../../models/agent.model';

@Component({
  selector: 'app-agent',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './agent.component.html',
  styleUrl: './agent.component.css'
})
export class AgentComponent implements OnInit {
  private fb = inject(FormBuilder);
  private agentService = inject(AgentService);

  readonly companyID = 'CP';

  isLoading = signal(false);
  isSearching = signal(false);
  errorMessage = signal('');
  agents = signal<Agent[]>([]);
  selectedAgent = signal<Agent | null>(null);
  isListVisible = signal(false);

  searchForm = this.fb.nonNullable.group({
    policyID: [''],
    agentID: [''],
    agentName: ['']
  });

  ngOnInit(): void {
    const agentID =
      this.searchForm.controls.agentID.value;

    if (agentID) {
      this.findAgent();
    }
  }

  findAgent(): void {
    const agentID =
      this.searchForm.controls.agentID.value.trim();

    if (!agentID) {
      this.errorMessage.set(
        'Masukkan Agent ID terlebih dahulu.'
      );
      this.selectedAgent.set(null);
      return;
    }

    this.errorMessage.set('');
    this.isLoading.set(true);

    this.agentService.getAgent(
      this.companyID,
      agentID,
      this.searchForm.controls.policyID.value
    ).subscribe({
      next: agent => {
        this.selectedAgent.set(agent);
        this.searchForm.patchValue({
          agentName: agent.agentName ?? ''
        });
        this.isLoading.set(false);
      },
      error: error => {
        console.error('Get agent error:', error);
        this.selectedAgent.set(null);
        this.isLoading.set(false);
        this.errorMessage.set(
          'Data agent tidak ditemukan.'
        );
      }
    });
  }

  showAgentList(): void {
    this.errorMessage.set('');
    this.isListVisible.set(true);
    this.searchAgents();
  }

  searchAgents(): void {
    this.isSearching.set(true);
    this.errorMessage.set('');

    const value =
      this.searchForm.getRawValue();

    this.agentService.searchAgents({
      companyID: this.companyID,
      policyID: value.policyID,
      agentID: value.agentID,
      agentName: value.agentName
    }).subscribe({
      next: agents => {
        this.agents.set(agents);
        this.isSearching.set(false);
      },
      error: error => {
        console.error('Search agent error:', error);
        this.agents.set([]);
        this.isSearching.set(false);
        this.errorMessage.set(
          'Gagal mengambil daftar agent.'
        );
      }
    });
  }

  selectAgent(agent: Agent): void {
    this.selectedAgent.set(agent);
    this.searchForm.patchValue({
      policyID: agent.policyID ?? '',
      agentID: agent.agentID ?? '',
      agentName: agent.agentName ?? ''
    });
    this.isListVisible.set(false);
  }

  closeAgentList(): void {
    this.isListVisible.set(false);
  }

  clear(): void {
    this.searchForm.reset({
      policyID: '',
      agentID: '',
      agentName: ''
    });
    this.selectedAgent.set(null);
    this.agents.set([]);
    this.errorMessage.set('');
  }

  statusLabel(agent: Agent | null): string {
    if (!agent) {
      return '';
    }

    if (agent.statusage) {
      return agent.statusage;
    }

    return agent.agentStatus === 'A'
      ? 'Active'
      : agent.agentStatus === 'I'
        ? 'Inactive'
        : agent.agentStatus;
  }
}