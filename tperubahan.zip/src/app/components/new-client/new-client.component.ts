import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterModule
} from '@angular/router';

@Component({
  selector: 'app-new-client',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './new-client.component.html',
  styleUrl: './new-client.component.css'
})
export class NewClientComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  errorMessage = signal('');
  isSubmitting = signal(false);

  clientType: 'insured' | 'debitur' = 'insured';

  clientForm = this.fb.nonNullable.group({
    companyID: ['CP', Validators.required],

    clientID: [''],
    idNameType: [''],
    idType: [''],
    idNumber: [''],
    idExpireDate: [''],

    clientName: ['', Validators.required],
    aliasName: [''],
    sex: ['', Validators.required],
    birthDate: ['', Validators.required],
    birthPlace: [''],
    nationality: [''],
    religion: [''],
    maritalStatus: [''],

    companyName: [''],
    businessLine: [''],
    jobTitle: [''],
    jobDescription: [''],

    email: [
      '',
      [
        Validators.email
      ]
    ],
    mobileNumber: [''],
    taxNumber: [''],

    companyAddress: [''],
    companyDistrict: [''],
    companyCity: [''],
    companyPostalCode: [''],
    companyPhoneNumber: [''],
    companyFaxNumber: [''],

    homeAddress: [''],
    homeDistrict: [''],
    homeCity: [''],
    homePostalCode: [''],
    homePhoneNumber: [''],
    homeFaxNumber: [''],

    mailingAddress: [''],
    mailingDistrict: [''],
    mailingCity: [''],
    mailingPostalCode: [''],
    mailingPhoneNumber: [''],
    mailingFaxNumber: ['']
  });

  ngOnInit(): void {
    const type =
      this.route.snapshot.queryParamMap.get('type');

    this.clientType =
      type === 'debitur'
        ? 'debitur'
        : 'insured';

    const companyID =
      this.route.snapshot.queryParamMap.get('companyID');

    if (companyID) {
      this.clientForm.controls.companyID.setValue(companyID);
    }
  }

  save(): void {
    this.errorMessage.set('');

    if (this.clientForm.invalid) {
      this.clientForm.markAllAsTouched();

      this.errorMessage.set(
        'Lengkapi field wajib dan periksa format data.'
      );

      return;
    }

    const payload = {
      clientType: this.clientType,
      ...this.clientForm.getRawValue()
    };

    this.isSubmitting.set(true);

    console.log('New client payload:', payload);

    /*
     * Hubungkan ke API di sini.
     *
     * Contoh:
     *
     * this.clientService.createClient(payload).subscribe({
     *   next: () => {
     *     this.isSubmitting.set(false);
     *     this.router.navigate(
     *       ['/dashboard/certificate/new'],
     *       {
     *         queryParams: {
     *           type: this.clientType
     *         }
     *       }
     *     );
     *   },
     *   error: err => {
     *     this.isSubmitting.set(false);
     *     this.errorMessage.set(
     *       err?.error?.message ??
     *       'Gagal menyimpan client.'
     *     );
     *   }
     * });
     */

    this.isSubmitting.set(false);
  }

  cancel(): void {
    this.router.navigate(
      ['/dashboard/certificate/new'],
      {
        queryParams: {
          type: this.clientType
        }
      }
    );
  }

  back(): void {
    this.cancel();
  }
}