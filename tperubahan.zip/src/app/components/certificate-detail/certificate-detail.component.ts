import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CertificateDetailService } from '../../services/certificate-detail.service';
import {
  CertificateHeader,
  CertificateInfo,
  ClientInfo,
  AgentInfo,
  ProductPackageOption,
  CoverageDocumentInfo,
  HealthQuestionInfo,
  ProductAppliedItem,
  PolicyHistoryItem,
  LetterItem,
  ActivityHistoryItem,
  InsuredFundResourceInfo
} from '../../models/certificate-detail.model';

type TabKey = 'certInfo' | 'clientAgent' | 'coverage' | 'financial' | 'policyHistory' | 'letters' | 'activity';

@Component({
  selector: 'app-certificate-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './certificate-detail.component.html',
  styleUrl: './certificate-detail.component.css'
})
export class CertificateDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private svc = inject(CertificateDetailService);

  // ── state utama ─────────────────────────────────────────────
  certificateID = signal('');
  header = signal<CertificateHeader | null>(null);
  certInfo = signal<CertificateInfo | null>(null);

  // Client, Agent & Beneficiary
  insuredClient = signal<ClientInfo | null>(null);
  debiturClient = signal<ClientInfo | null>(null);
  agent = signal<AgentInfo | null>(null);

  // Coverage & document
  packageOptions = signal<ProductPackageOption[]>([]);
  coverage = signal<CoverageDocumentInfo[]>([]);

  // Financial & health
  insuredFundResource = signal<InsuredFundResourceInfo | null>(null);
  healthQuestions = signal<HealthQuestionInfo[]>([]);

  // Policy history
  productApplied = signal<ProductAppliedItem[]>([]);
  policyHistory = signal<PolicyHistoryItem[]>([]);

  // Letters & activity
  letters = signal<LetterItem[]>([]);
  activity = signal<ActivityHistoryItem[]>([]);

  // UI state
  isLoading = signal(false);
  errorMessage = signal('');
  activeTab = signal<TabKey>('certInfo');

  // Placeholder default untuk Healthy Information (jika API kosong)
  defaultHealthPlaceholders = [
    { no: '1', question: 'Tekanan darah tinggi' },
    { no: '2', question: 'Gangguan pernapasan' },
    { no: '3', question: 'Penyakit darah' },
    { no: '4', question: 'Penyakit jantung' },
    { no: '5', question: 'Gangguan hati (termasuk Hepatitis B carrier)' },
    { no: '6', question: 'AIDS / AIDS Related Complex' },
    { no: '7', question: 'Kanker atau tumor / benjolan' },
    { no: '8', question: 'Penyakit saluran kencing' },
    { no: '9', question: 'Gangguan pada tulang, tulang belakang / otot' },
    { no: '10', question: 'Nyeri dada' },
    { no: '11', question: 'Stroke' },
    { no: '12', question: 'Penyakit ginjal' },
    { no: '13', question: 'Diabetes (kencing manis)' },
  ];

  // ── lifecycle ───────────────────────────────────────────────
  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('certificateID');
    if (id) {
      this.certificateID.set(id);
      this.loadHeaderAndCertInfo(id);
    }
  }

  // ── load header + certificate info ──────────────────────────
  loadHeaderAndCertInfo(certificateID: string): void {
    this.isLoading.set(true);
    this.errorMessage.set('');

    this.svc.getDetail(certificateID).subscribe({
      next: (res) => {
        this.header.set(res.header);
        this.certInfo.set(res.certInfo);
        this.isLoading.set(false);
        this.setTab('certInfo');
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? `Failed to load certificate detail (status: ${err?.status})`);
        this.isLoading.set(false);
      }
    });
  }

  // ── tab handler ─────────────────────────────────────────────
  setTab(tab: TabKey): void {
    this.activeTab.set(tab);

    const h = this.header();
    if (!h?.memberID) return;

    const memberID = h.memberID;
    const companyID = h.companyID ?? '01';
    const policyID = h.policyID ?? '';

    switch (tab) {
      case 'certInfo':
        // hanya header + certInfo, sudah di-load di loadHeaderAndCertInfo
        break;

      case 'clientAgent':
        // Client (insured)
        if (!this.insuredClient() && h.insuredID) {
          this.svc.getClientInfo(h.insuredID).subscribe({
            next: d => this.insuredClient.set(d),
            error: err => console.error('Insured client error:', err)
          });
        }
        // Client (debitur)
        if (!this.debiturClient() && h.debiturID) {
          this.svc.getClientInfo(h.debiturID).subscribe({
            next: d => this.debiturClient.set(d),
            error: err => console.error('Debitur client error:', err)
          });
        }
        // Agent
        if (!this.agent()) {
          this.svc.getAgentInfo(memberID, companyID, policyID).subscribe({
            next: d => this.agent.set(d),
            error: err => console.error('Agent info error:', err)
          });
        }
        break;

      case 'coverage':
        if (this.coverage().length === 0) {
          // ambil daftar package dulu
          this.svc.getProductPackageOptions(companyID).subscribe({
            next: opts => {
              this.packageOptions.set(opts);
              const pkgID = opts[0]?.productPackageID;
              if (pkgID) {
                this.svc.getCoverageDocument(memberID, companyID, pkgID).subscribe({
                  next: d => this.coverage.set(d),
                  error: err => console.error('Coverage error:', err)
                });
              }
            },
            error: err => console.error('Product package error:', err)
          });
        }
        break;

      case 'financial':
        // fund resource (sementara kosong, nanti bisa diisi dari API)
        if (!this.insuredFundResource()) {
          this.insuredFundResource.set({});
        }
        // health questions
        if (this.healthQuestions().length === 0 && h.productType) {
          this.svc.getFinancialHealth(memberID, companyID, h.productType, policyID).subscribe({
            next: d => this.healthQuestions.set(d),
            error: err => {
              console.error('Health questions error:', err);
              this.healthQuestions.set([]);
            }
          });
        }
        break;

      case 'policyHistory':
        if (this.productApplied().length === 0) {
          this.svc.getProductApplied(memberID).subscribe({
            next: d => this.productApplied.set(d),
            error: err => console.error('Product applied error:', err)
          });
        }
        if (this.policyHistory().length === 0) {
          this.svc.getPolicyHistory(memberID).subscribe({
            next: d => this.policyHistory.set(d),
            error: err => console.error('Policy history error:', err)
          });
        }
        break;

      case 'letters':
        if (this.letters().length === 0) {
          this.svc.getLetters(memberID).subscribe({
            next: d => this.letters.set(d),
            error: err => console.error('Letters error:', err)
          });
        }
        break;

      case 'activity':
        if (this.activity().length === 0) {
          this.svc.getActivityHistory(memberID).subscribe({
            next: d => this.activity.set(d),
            error: err => console.error('Activity history error:', err)
          });
        }
        break;
    }
  }

  // ── helper: hitung umur insured ─────────────────────────────
  calculateAge(birthDate: string | undefined | null): number | string {
    if (!birthDate) return '-';
    const diffMs = new Date().getTime() - new Date(birthDate).getTime();
    return Math.floor(diffMs / 31557600000);
  }

  // ── navigation ─────────────────────────────────────────────
  goBack(): void {
    this.router.navigate(['/dashboard/certificate-list']);
  }

  // ── status css class ───────────────────────────────────────
  getStatusClass(status: string | null | undefined): string {
    const map: Record<string, string> = {
      ACT: 'status-active',
      LAP: 'status-lapsed',
      TRM: 'status-terminated',
      PND: 'status-pending'
    };
    return map[status ?? ''] ?? 'status-secondary';
  }
}