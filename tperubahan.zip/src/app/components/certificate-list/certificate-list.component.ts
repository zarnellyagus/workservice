import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { CertificateService } from '../../services/certificate.service';
import { CodeService } from '../../services/code.service';
import { Certificate, CertificateFilter } from '../../models/certificate.model';
import { CodeOption } from '../../models/code.model';

@Component({
  selector: 'app-certificate-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePipe],
  templateUrl: './certificate-list.component.html',
  styleUrl: './certificate-list.component.css'
})
export class CertificateListComponent implements OnInit {
  private svc     = inject(CertificateService);
  private codeSvc = inject(CodeService);
  private fb      = inject(FormBuilder);
  private router  = inject(Router);

  // ── Data signals ──────────────────────────────────────────────
  certificates  = signal<Certificate[]>([]);
  totalRecords  = signal(0);
  totalPages    = signal(0);
  isLoading     = signal(false);
  errorMessage  = signal('');

  // ── Pagination & sort ─────────────────────────────────────────
  pageNumber  = signal(1);
  pageSize    = signal(50);
  sortColumn  = signal('appReceiveDate');
  sortDir     = signal<'ASC' | 'DESC'>('DESC');

  // ── UI state ──────────────────────────────────────────────────
  showMoreCriteria = signal(false);

  // ── Computed ──────────────────────────────────────────────────
  startRow = computed(() => (this.pageNumber() - 1) * this.pageSize() + 1);
  endRow   = computed(() => Math.min(this.pageNumber() * this.pageSize(), this.totalRecords()));
  pages    = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  // ── Dropdown options (dari API / tdcode) ──────────────────────
  statusOptions = signal<CodeOption[]>([
    { codeID: '', codeName: '', codeSequence: 0 }
  ]);

  // ── Filter form ───────────────────────────────────────────────
  filterForm: FormGroup = this.fb.group({
    memberID:          [''],
    companyID:         [''],
    policyID:          [''],
    certificateID:     [''],
    certificateStatus: [''],
    insuredName:       [''],
    uwStatus:          [''],
    productType:       [''],
    dateType:          [''],
    dateFrom:          [''],
    dateTo:            [''],
  });

  // ── Lifecycle ─────────────────────────────────────────────────
  ngOnInit(): void {
    this.loadStatusOptions();
    this.loadData();
  }

  private loadStatusOptions(): void {
    const companyId = this.filterForm.value.companyID || '01';
    this.codeSvc.getCodes(companyId, 'CRTSTS').subscribe({
      next: (data) => this.statusOptions.set(data),
      error: () => this.statusOptions.set([
        { codeID: '', codeName: 'All Status', codeSequence: 0 }
      ])
    });
  }

  loadData(): void {
    this.isLoading.set(true);
    this.errorMessage.set('');
    const f = this.filterForm.value;

    const filter: CertificateFilter = {
      memberID:          f.memberID          || undefined,
      companyID:         f.companyID         || undefined,
      policyID:          f.policyID          || undefined,
      certificateID:     f.certificateID     || undefined,
      certificateStatus: f.certificateStatus || undefined,
      insuredName:       f.insuredName       || undefined,
      pageNumber:        this.pageNumber(),
      pageSize:          this.pageSize(),
      sortColumn:        this.sortColumn(),
      sortDirection:     this.sortDir(),
    };

    this.svc.getList(filter).subscribe({
      next: (res) => {
        this.certificates.set(res.data);
        this.totalRecords.set(res.totalRecords);
        this.totalPages.set(res.totalPages);
        this.isLoading.set(false);
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? 'Failed to load data');
        this.isLoading.set(false);
      }
    });
  }

  isTaskMenuOpen = false;

toggleTaskMenu(event?: MouseEvent): void {
  event?.stopPropagation();
  this.isTaskMenuOpen = !this.isTaskMenuOpen;
}

closeTaskMenu(): void {
  this.isTaskMenuOpen = false;
}


newCertificate(): void {
  this.closeTaskMenu();
  this.router.navigate(['/dashboard/certificate/new']);
}
uploadCertificate(): void {
  this.closeTaskMenu();
  this.router.navigate(['/certificate/upload']);
}

validateCertificate(): void {
  this.closeTaskMenu();
  this.router.navigate(['/certificate/validate']);
}

completeCertificate(): void {
  this.closeTaskMenu();
  this.router.navigate(['/certificate/complete']);
}

  // ── Actions ───────────────────────────────────────────────────
  search(): void {
    this.pageNumber.set(1);
    this.loadData();
  }

  resetFilter(): void {
    this.filterForm.reset({
      memberID: '', companyID: '', policyID: '',
      certificateID: '', certificateStatus: '',
      insuredName: '', uwStatus: '', productType: '',
      dateType: '', dateFrom: '', dateTo: '',
    });
    this.pageNumber.set(1);
    this.loadData();
  }

  toggleMoreCriteria(): void {
    this.showMoreCriteria.set(!this.showMoreCriteria());
  }

  onPageSizeChange(event: Event): void {
    this.pageSize.set(+((event.target as HTMLSelectElement).value));
    this.pageNumber.set(1);
    this.loadData();
  }

  // ── Sort ──────────────────────────────────────────────────────
  sort(col: string): void {
    if (this.sortColumn() === col) {
      this.sortDir.set(this.sortDir() === 'ASC' ? 'DESC' : 'ASC');
    } else {
      this.sortColumn.set(col);
      this.sortDir.set('ASC');
    }
    this.loadData();
  }

  sortIcon(col: string): string {
    if (this.sortColumn() !== col) return '↕';
    return this.sortDir() === 'ASC' ? '↑' : '↓';
  }

  // ── Pagination ────────────────────────────────────────────────
  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages()) return;
    this.pageNumber.set(page);
    this.loadData();
  }

  // ── Navigasi ke halaman Certificate Detail (pengganti modal) ───
  openDetail(item: Certificate): void {
    if (!item.certificateID) {
      this.errorMessage.set('Certificate ID tidak valid');
      return;
    }
    this.router.navigate(['/dashboard/certificate-detail', item.certificateID]);
  }

  // ── CSS class helpers ─────────────────────────────────────────
  getStatusClass(status: string | null): string {
    const map: Record<string, string> = {
      ACT: 'status-active',
      LAP: 'status-lapsed',
      TRM: 'status-terminated',
      PND: 'status-pending',
    };
    return map[status ?? ''] ?? 'status-secondary';
  }

  getProgressClass(status: string | null): string {
    const map: Record<string, string> = {
      'Postpone': 'progress-postpone',
      'Active':   'progress-active',
      'Pending':  'progress-pending',
    };
    return map[status ?? ''] ?? 'progress-default';
  }
}