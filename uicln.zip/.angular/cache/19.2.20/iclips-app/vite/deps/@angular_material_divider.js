import {
  MatDivider,
  MatDividerModule
} from "./chunk-V2MG55SD.js";
import "./chunk-IBYU652R.js";
import "./chunk-IBCXT2XP.js";
import "./chunk-QEFLZ7F2.js";
import "./chunk-UU72T5BU.js";
import "./chunk-DVMK5NTK.js";
import "./chunk-6HXH3O7U.js";
import "./chunk-CAZOW7N2.js";
import "./chunk-FFZIAYYX.js";
import "./chunk-6Q4RANH6.js";
import "./chunk-CXCX2JKZ.js";
export {
  MatDivider,
  MatDividerModule
};
