import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import {
  CertificateDetailResponse,
  ClientInfo,
  AgentInfo,
  ProductPackageOption,
  CoverageDocumentInfo,
  HealthQuestionInfo,
  ProductAppliedItem,
  PolicyHistoryItem,
  LetterItem,
  ActivityHistoryItem,
  PolicyOption
} from '../models/certificate-detail.model';

@Injectable({
  providedIn: 'root'
})
export class CertificateDetailService {
  private readonly http = inject(HttpClient);

  private readonly baseUrl =
    'https://localhost:7201/api/certificate';

  // ───────────────────────────────────────────────────────────
  // CERTIFICATE DETAIL
  // ───────────────────────────────────────────────────────────

  getDetail(
    certificateID: string
  ): Observable<CertificateDetailResponse> {
    return this.http.get<CertificateDetailResponse>(
      `${this.baseUrl}/${encodeURIComponent(certificateID)}/detail`
    );
  }

  // ───────────────────────────────────────────────────────────
  // CLIENT
  // ───────────────────────────────────────────────────────────

  getClientInfo(
    clientID: string
  ): Observable<ClientInfo> {
    return this.http.get<ClientInfo>(
      `${this.baseUrl}/client/${encodeURIComponent(clientID)}`
    );
  }

  // ───────────────────────────────────────────────────────────
  // AGENT
  // ───────────────────────────────────────────────────────────

  getAgentInfo(
    memberID: string,
    companyID: string,
    policyID: string
  ): Observable<AgentInfo> {
    const params = new HttpParams()
      .set('memberID', memberID)
      .set('companyID', companyID)
      .set('policyID', policyID);

    return this.http.get<AgentInfo>(
      `${this.baseUrl}/agent`,
      { params }
    );
  }

  // ───────────────────────────────────────────────────────────
  // POLICY OPTIONS
  // ───────────────────────────────────────────────────────────

  getPolicyOptions(
    companyID: string
  ): Observable<PolicyOption[]> {
    const params = new HttpParams()
      .set('companyID', companyID);

    return this.http.get<PolicyOption[]>(
      `${this.baseUrl}/policy-options`,
      { params }
    );
  }

  // ───────────────────────────────────────────────────────────
  // PRODUCT PACKAGE
  // ───────────────────────────────────────────────────────────

  getProductPackageOptions(
    companyID: string,
    productPackageID?: string
  ): Observable<ProductPackageOption[]> {
    let params = new HttpParams()
      .set('companyID', companyID);

    if (productPackageID) {
      params = params.set(
        'productPackageID',
        productPackageID
      );
    }

    return this.http.get<ProductPackageOption[]>(
      `${this.baseUrl}/product-package`,
      { params }
    );
  }

  // ───────────────────────────────────────────────────────────
  // COVERAGE DOCUMENT
  // ───────────────────────────────────────────────────────────

  getCoverageDocument(
    memberID: string,
    companyID: string,
    productPackageID: string
  ): Observable<CoverageDocumentInfo[]> {
    const params = new HttpParams()
      .set('companyID', companyID)
      .set('productPackageID', productPackageID);

    return this.http.get<CoverageDocumentInfo[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/coverage-document`,
      { params }
    );
  }

  // ───────────────────────────────────────────────────────────
  // FINANCIAL & HEALTH
  // ───────────────────────────────────────────────────────────

  getFinancialHealth(
    memberID: string,
    companyID: string,
    productID: string,
    policyID: string
  ): Observable<HealthQuestionInfo[]> {
    const params = new HttpParams()
      .set('companyID', companyID)
      .set('productID', productID)
      .set('policyID', policyID);

    return this.http.get<HealthQuestionInfo[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/financial-health`,
      { params }
    );
  }

  // ───────────────────────────────────────────────────────────
  // POLICY HISTORY - PRODUCT APPLIED
  // ───────────────────────────────────────────────────────────

  getProductApplied(
    memberID: string
  ): Observable<ProductAppliedItem[]> {
    return this.http.get<ProductAppliedItem[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/policy-history/product-applied`
    );
  }

  // ───────────────────────────────────────────────────────────
  // POLICY HISTORY - TRANSACTIONS
  // ───────────────────────────────────────────────────────────

  getPolicyHistory(
    memberID: string
  ): Observable<PolicyHistoryItem[]> {
    return this.http.get<PolicyHistoryItem[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/policy-history`
    );
  }

  // ───────────────────────────────────────────────────────────
  // LETTERS
  // ───────────────────────────────────────────────────────────

  getLetters(
    memberID: string
  ): Observable<LetterItem[]> {
    return this.http.get<LetterItem[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/letters`
    );
  }

  // ───────────────────────────────────────────────────────────
  // ACTIVITY HISTORY
  // ───────────────────────────────────────────────────────────

  getActivityHistory(
    memberID: string
  ): Observable<ActivityHistoryItem[]> {
    return this.http.get<ActivityHistoryItem[]>(
      `${this.baseUrl}/${encodeURIComponent(memberID)}/activity-history`
    );
  }
}