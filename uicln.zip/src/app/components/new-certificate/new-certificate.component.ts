import {
  CommonModule
} from '@angular/common';

import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';

import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Router,
  RouterModule
} from '@angular/router';

import {
  CertificateDetailService
} from '../../services/certificate-detail.service';

import {
  PolicyOption
} from '../../models/certificate-detail.model';

@Component({
  selector: 'app-new-certificate',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './new-certificate.component.html',
  styleUrl: './new-certificate.component.css'
})
export class NewCertificateComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private svc = inject(CertificateDetailService);

  isSubmitting = signal(false);
  isLoadingPolicies = signal(false);
  errorMessage = signal('');

  policyOptions = signal<PolicyOption[]>([]);

  sexOptions = [
    { value: 'M', label: 'Male' },
    { value: 'F', label: 'Female' }
  ];

  newCertificateForm = this.fb.group({
    policyID: ['', Validators.required],

    ownerName: [
      { value: '', disabled: true }
    ],

    productType: [
      { value: '', disabled: true }
    ],

    insuredName: [
      '',
      Validators.required
    ],

    insuredID: [
      '',
      Validators.required
    ],

    insuredBirthDate: [
      '',
      Validators.required
    ],

    insuredSex: [
      '',
      Validators.required
    ],

    insuredAlternateID: [
      ''
    ],

    insuredAsDebitur: [
      false
    ],

    debiturName: [
      '',
      Validators.required
    ],

    debiturID: [
      '',
      Validators.required
    ],

    debiturBirthDate: [
      '',
      Validators.required
    ],

    debiturSex: [
      '',
      Validators.required
    ],

    debiturAlternateID: [
      ''
    ],

    agentID: [
      '',
      Validators.required
    ],

    agentName: [
      { value: '', disabled: true }
    ],

    branchName: [
      { value: '', disabled: true }
    ],

    mainBranchName: [
      { value: '', disabled: true }
    ],

    areaName: [
      { value: '', disabled: true }
    ],

    credamName: [
      { value: '', disabled: true }
    ]
  });

  ngOnInit(): void {
    this.loadPolicyOptions();
  }

  loadPolicyOptions(): void {
    this.isLoadingPolicies.set(true);
    this.errorMessage.set('');

    // Ganti dengan CompanyID dari login/session.
    const companyID = 'CP';

    this.svc.getPolicyOptions(companyID).subscribe({
      next: (options: PolicyOption[]) => {
        this.policyOptions.set(options);
        this.isLoadingPolicies.set(false);
      },

      error: (err: unknown) => {
        console.error('Policy options error:', err);

        this.policyOptions.set([]);
        this.errorMessage.set(
          'Policy list gagal dimuat.'
        );

        this.isLoadingPolicies.set(false);
      }
    });
  }

  onPolicyChange(): void {
    const policyID =
      this.newCertificateForm.controls.policyID.value;

    const selectedPolicy = this.policyOptions()
      .find(policy => policy.policyID === policyID);

    this.newCertificateForm.patchValue({
      ownerName: selectedPolicy?.policyOwnerName ?? '',
      productType: selectedPolicy?.productTypeName ?? ''
    });
  }

  onInsuredAsDebiturChange(): void {
    const checked =
      this.newCertificateForm.controls.insuredAsDebitur.value === true;

    if (checked) {
      const insured =
        this.newCertificateForm.getRawValue();

      this.newCertificateForm.patchValue({
        debiturName: insured.insuredName,
        debiturID: insured.insuredID,
        debiturBirthDate: insured.insuredBirthDate,
        debiturSex: insured.insuredSex,
        debiturAlternateID: insured.insuredAlternateID
      });

      this.newCertificateForm.controls.debiturName.disable();
      this.newCertificateForm.controls.debiturID.disable();
      this.newCertificateForm.controls.debiturBirthDate.disable();
      this.newCertificateForm.controls.debiturSex.disable();
      this.newCertificateForm.controls.debiturAlternateID.disable();
    } else {
      this.newCertificateForm.controls.debiturName.enable();
      this.newCertificateForm.controls.debiturID.enable();
      this.newCertificateForm.controls.debiturBirthDate.enable();
      this.newCertificateForm.controls.debiturSex.enable();
      this.newCertificateForm.controls.debiturAlternateID.enable();

      this.newCertificateForm.patchValue({
        debiturName: '',
        debiturID: '',
        debiturBirthDate: '',
        debiturSex: '',
        debiturAlternateID: ''
      });
    }
  }

  findInsuredClient(): void {
    this.errorMessage.set('');

    const clientID =
      this.newCertificateForm.controls.insuredID.value;

    if (!clientID) {
      this.errorMessage.set(
        'Masukkan Insured ID terlebih dahulu.'
      );
      return;
    }

    console.log('Find insured client:', clientID);

    // Sambungkan ke endpoint client search jika sudah tersedia.
  }

  findDebiturClient(): void {
    this.errorMessage.set('');

    const clientID =
      this.newCertificateForm.controls.debiturID.value;

    if (!clientID) {
      this.errorMessage.set(
        'Masukkan Debitur ID terlebih dahulu.'
      );
      return;
    }

    console.log('Find debitur client:', clientID);

    // Sambungkan ke endpoint client search jika sudah tersedia.
  }

  viewInsuredDetail(): void {
    const clientID =
      this.newCertificateForm.controls.insuredID.value;

    if (!clientID) {
      this.errorMessage.set('Insured ID belum diisi.');
      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  viewDebiturDetail(): void {
    const clientID =
      this.newCertificateForm.controls.debiturID.value;

    if (!clientID) {
      this.errorMessage.set('Debitur ID belum diisi.');
      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  findAgent(): void {
    this.errorMessage.set('');

    const agentID =
      this.newCertificateForm.controls.agentID.value;

    if (!agentID) {
      this.errorMessage.set(
        'Masukkan Agent ID terlebih dahulu.'
      );
      return;
    }

    console.log('Find agent:', agentID);

    // Sambungkan ke endpoint agent search jika tersedia.
  }

  next(): void {
    this.errorMessage.set('');

    if (this.newCertificateForm.invalid) {
      this.newCertificateForm.markAllAsTouched();

      this.errorMessage.set(
        'Lengkapi field wajib sebelum melanjutkan.'
      );

      return;
    }

    const formValue =
      this.newCertificateForm.getRawValue();

    console.log(
      'New certificate step 1:',
      formValue
    );

    // Contoh:
    //
    // this.router.navigate(
    //   ['/dashboard/certificate/new/coverage'],
    //   {
    //     state: {
    //       certificate: formValue
    //     }
    //   }
    // );
  }

  back(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }

  cancel(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }
}