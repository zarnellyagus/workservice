export interface CertificateHeader {
  memberID: string; companyID?: string; policyID?: string; policyOwnerName?: string;
  productType?: string; productTypeName?: string; partnerID?: string; partnerName?: string;
  certificateID: string; insuredID?: string; insuredName?: string; debiturID?: string; debiturName?: string;
  certificateStatus?: string; certificateStatusName?: string; underwritingStatus?: string; underwritingStatusName?: string;
  pendingTransNo?: string; pendingTransType?: string; pendingTransTypeName?: string;
  progressStatus?: string; progressStatusName?: string; medicalType?: string; pendingItem?: string; medicalTypeName?: string;
}

export interface CertificateInfo {
  memberID: string; applicationNo?: string; effectiveDate?: string; appReceiveDate?: string;
  appSignedDate?: string; coverNoteDate?: string; joinIncome?: boolean; mainCertificateID?: string;
  currency?: string; billingMode?: string; billAmount?: number; premiumNettAmount?: number;
  premiumTaxAmount?: number; premiumTaxRate?: number; extraPremiumRate?: string; extraPremiumAmount?: number;
  extraPremiumNett?: number; totalPremium?: number; allowedProcess?: number; inforceDate?: string;
  agreementNo?: string; loanDuration?: number; loanMaturityDate?: string; weight?: number; height?: number;
  bmiRate?: number; rating?: number; prevCertificateID?: string; surrenderAmount?: number;
  needUnderwritingProcess?: boolean; notes?: string; extraMortalityRating?: number;
}

export interface CertificateDetailResponse { header: CertificateHeader; certInfo: CertificateInfo; }

export interface ClientInfo {
  companyID?: string; clientID?: string; alternateID?: string; clientType?: string; clientName?: string;
  nameType?: string; aliasName?: string; citizenship?: string; idType?: string; idNumber?: string;
  idExpireDate?: string; sex?: string; birthPlace?: string; birthDate?: string; maritalStatus?: string;
  religion?: string; companyName?: string; officeAddress?: string; officeCity?: string; officePhone?: string;
  homeAddress?: string; homeCity?: string; homePhone?: string; emailAddress?: string; mobileNumber?: string;
}

export interface AgentInfo {
  policyID?: string; companyID?: string; agentID?: string; agentName?: string; branchID?: string;
  branchName?: string; mainBranchID?: string; mainBranchName?: string; areaID?: string; areaName?: string;
  credamID?: string; credamName?: string; agentStatus?: string;
}

export interface ProductPackageOption { companyID?: string; productPackageID?: string; productPackageName?: string; }

export interface CoverageDocumentInfo {
  certificateCoverageID?: number; planID?: string; planName?: string; faceAmount?: number;
  coverageDuration?: number; durationUnit?: string; durationUnitName?: string;
  coverageEffectiveDate?: string; coverageMaturityDate?: string; planSequence?: number; productPackageID?: string;
}

export interface InsuredFundResourceInfo {
  salaryIncome?: string;
  spouseIncome?: string;
  investmentIncome?: string;
  businessIncome?: string;
  otherIncome?: number;
  annualNetIncome?: number;
  numberOfDependent?: number;
}
export interface ProductAppliedItem {
  isUsed?: number; dataSource?: string; companyID?: string; companyName?: string; policyID?: string;
  planID?: string; planName?: string; effectiveDate?: string; faceAmount?: number; cvgNum?: string;
}

export interface PolicyHistoryItem {
  memberID: string; transactionID?: string; transactionName?: string; transactionDate?: string; remarks?: string;
}
export interface HealthQuestionInfo {
  noUrut?: string;          // Nomor urut pertanyaan (HealthQueID atau running number)
  healthQueID?: string;     // ID pertanyaan (HealthQueID)
  healthQueDesc?: string;   // Deskripsi pertanyaan (HealthQueDesc)
  isAnswer?: string;        // Flag di master (Y/N, dsb.)
  answer?: number;          // Jawaban, 1 = Yes, 0 = No
  explaination?: string;    // Penjelasan tambahan dari nasabah
}

export interface LetterItem {
  transReportID?: string; reportID?: string; reportName?: string; reportDate?: string;
  createdBy?: string; createdDate?: string; reportLink?: string; notes?: string;
}

export interface ActivityHistoryItem {
  historyID?: string; historyDate?: string; historyType?: string; historyBy?: string; historyNotes?: string;
}
export interface PolicyOption {
  policyID: string;
  policyOwnerName?: string;
  productTypeName?: string;
}
export interface ClientSearchResult {
  companyID?: string;
  clientID?: string;
  alternateID?: string;
  clientName?: string;
  birthDate?: string;
  sex?: string;
}