import {
  CommonModule
} from '@angular/common';

import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';

import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Router,
  RouterModule
} from '@angular/router';

import {
  CertificateDetailService
} from '../../services/certificate-detail.service';

import {
  ClientSearchResult,
  PolicyOption
} from '../../models/certificate-detail.model';

@Component({
  selector: 'app-new-certificate',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './new-certificate.component.html',
  styleUrl: './new-certificate.component.css'
})
export class NewCertificateComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private svc = inject(CertificateDetailService);

  // ─────────────────────────────────────────────────────────
  // UI STATE
  // ─────────────────────────────────────────────────────────

  isSubmitting = signal(false);
  isLoadingPolicies = signal(false);
  isSearchingClients = signal(false);
  errorMessage = signal('');

  // ─────────────────────────────────────────────────────────
  // POLICY
  // ─────────────────────────────────────────────────────────

  policyOptions = signal<PolicyOption[]>([]);

  // Ganti sesuai company dari login/session.
  readonly companyID = 'CP';

  // ─────────────────────────────────────────────────────────
  // CLIENT SEARCH MODAL
  // ─────────────────────────────────────────────────────────

  clientSearchResults = signal<ClientSearchResult[]>([]);
  isClientSearchOpen = signal(false);

  clientSearchType = signal<'insured' | 'debitur'>(
    'insured'
  );

  // ─────────────────────────────────────────────────────────
  // OPTIONS
  // ─────────────────────────────────────────────────────────

  sexOptions = [
    {
      value: 'M',
      label: 'Male'
    },
    {
      value: 'F',
      label: 'Female'
    }
  ];

  // ─────────────────────────────────────────────────────────
  // FORM
  // ─────────────────────────────────────────────────────────

  newCertificateForm = this.fb.group({
    policyID: [
      '',
      Validators.required
    ],

    ownerName: [
      {
        value: '',
        disabled: true
      }
    ],

    productType: [
      {
        value: '',
        disabled: true
      }
    ],

    insuredName: [
      '',
      Validators.required
    ],

    insuredID: [
      '',
      Validators.required
    ],

    insuredBirthDate: [
      '',
      Validators.required
    ],

    insuredSex: [
      '',
      Validators.required
    ],

    insuredAlternateID: [
      ''
    ],

    insuredAsDebitur: [
      false
    ],

    debiturName: [
      '',
      Validators.required
    ],

    debiturID: [
      '',
      Validators.required
    ],

    debiturBirthDate: [
      '',
      Validators.required
    ],

    debiturSex: [
      '',
      Validators.required
    ],

    debiturAlternateID: [
      ''
    ],

    agentID: [
      '',
      Validators.required
    ],

    agentName: [
      {
        value: '',
        disabled: true
      }
    ],

    branchName: [
      {
        value: '',
        disabled: true
      }
    ],

    mainBranchName: [
      {
        value: '',
        disabled: true
      }
    ],

    areaName: [
      {
        value: '',
        disabled: true
      }
    ],

    credamName: [
      {
        value: '',
        disabled: true
      }
    ]
  });

  // ─────────────────────────────────────────────────────────
  // LIFECYCLE
  // ─────────────────────────────────────────────────────────

  ngOnInit(): void {
    this.loadPolicyOptions();
  }

  // ─────────────────────────────────────────────────────────
  // POLICY
  // ─────────────────────────────────────────────────────────

  loadPolicyOptions(): void {
    this.isLoadingPolicies.set(true);
    this.errorMessage.set('');

    this.svc.getPolicyOptions(this.companyID).subscribe({
      next: (options: PolicyOption[]) => {
        this.policyOptions.set(options);
        this.isLoadingPolicies.set(false);
      },

      error: (err: unknown) => {
        console.error(
          'Policy options error:',
          err
        );

        this.policyOptions.set([]);
        this.isLoadingPolicies.set(false);
        this.errorMessage.set(
          'Policy list gagal dimuat.'
        );
      }
    });
  }

  onPolicyChange(): void {
    const policyID =
      this.newCertificateForm.controls.policyID.value;

    const selectedPolicy =
      this.policyOptions().find(
        policy => policy.policyID === policyID
      );

    this.newCertificateForm.patchValue({
      ownerName: selectedPolicy?.policyOwnerName ?? '',
      productType: selectedPolicy?.productTypeName ?? ''
    });
  }

  // ─────────────────────────────────────────────────────────
  // CLIENT SEARCH
  // ─────────────────────────────────────────────────────────

  findInsuredClient(): void {
    const clientName =
      this.newCertificateForm.controls.insuredName.value ?? '';

    const clientID =
      this.newCertificateForm.controls.insuredID.value ?? '';

    const alternateID =
      this.newCertificateForm.controls.insuredAlternateID.value ?? '';

    this.openClientSearch(
      'insured',
      clientName,
      clientID,
      alternateID
    );
  }

  findDebiturClient(): void {
    const clientName =
      this.newCertificateForm.controls.debiturName.value ?? '';

    const clientID =
      this.newCertificateForm.controls.debiturID.value ?? '';

    const alternateID =
      this.newCertificateForm.controls.debiturAlternateID.value ?? '';

    this.openClientSearch(
      'debitur',
      clientName,
      clientID,
      alternateID
    );
  }

  private openClientSearch(
    type: 'insured' | 'debitur',
    clientName: string,
    clientID: string,
    alternateID: string
  ): void {
    this.errorMessage.set('');

    if (
      !clientName.trim() &&
      !clientID.trim() &&
      !alternateID.trim()
    ) {
      this.errorMessage.set(
        type === 'insured'
          ? 'Isi Insured Name, Insured ID, atau Alternate ID.'
          : 'Isi Debitur Name, Debitur ID, atau Alternate ID.'
      );

      return;
    }

    this.clientSearchType.set(type);
    this.clientSearchResults.set([]);
    this.isClientSearchOpen.set(true);
    this.isSearchingClients.set(true);

    this.svc.searchClients(
      this.companyID,
      clientName,
      clientID,
      alternateID
    ).subscribe({
      next: (results: ClientSearchResult[]) => {
        this.clientSearchResults.set(results);
        this.isSearchingClients.set(false);
      },

      error: (err: unknown) => {
        console.error(
          'Client search error:',
          err
        );

        this.clientSearchResults.set([]);
        this.isSearchingClients.set(false);
        this.errorMessage.set(
          'Pencarian client gagal.'
        );
      }
    });
  }

  selectClient(
    client: ClientSearchResult
  ): void {
    const type = this.clientSearchType();

    if (type === 'insured') {
      this.newCertificateForm.patchValue({
        insuredName: client.clientName ?? '',
        insuredID: client.clientID ?? '',
        insuredAlternateID: client.alternateID ?? '',
        insuredBirthDate: this.toDateInput(client.birthDate),
        insuredSex: client.sex ?? ''
      });
    } else {
      this.newCertificateForm.patchValue({
        debiturName: client.clientName ?? '',
        debiturID: client.clientID ?? '',
        debiturAlternateID: client.alternateID ?? '',
        debiturBirthDate: this.toDateInput(client.birthDate),
        debiturSex: client.sex ?? ''
      });
    }

    this.closeClientSearch();
  }

  closeClientSearch(): void {
    this.isClientSearchOpen.set(false);
    this.clientSearchResults.set([]);
    this.isSearchingClients.set(false);
  }

  private toDateInput(
    value?: string
  ): string {
    if (!value) {
      return '';
    }

    return value.substring(0, 10);
  }

  // ─────────────────────────────────────────────────────────
  // INSURED AS DEBITUR
  // ─────────────────────────────────────────────────────────

  onInsuredAsDebiturChange(): void {
    const checked =
      this.newCertificateForm.controls.insuredAsDebitur.value === true;

    const debiturName =
      this.newCertificateForm.controls.debiturName;

    const debiturID =
      this.newCertificateForm.controls.debiturID;

    const debiturBirthDate =
      this.newCertificateForm.controls.debiturBirthDate;

    const debiturSex =
      this.newCertificateForm.controls.debiturSex;

    const debiturAlternateID =
      this.newCertificateForm.controls.debiturAlternateID;

    if (checked) {
      const insured =
        this.newCertificateForm.getRawValue();

      this.newCertificateForm.patchValue({
        debiturName: insured.insuredName,
        debiturID: insured.insuredID,
        debiturBirthDate: insured.insuredBirthDate,
        debiturSex: insured.insuredSex,
        debiturAlternateID: insured.insuredAlternateID
      });

      debiturName.disable();
      debiturID.disable();
      debiturBirthDate.disable();
      debiturSex.disable();
      debiturAlternateID.disable();
    } else {
      debiturName.enable();
      debiturID.enable();
      debiturBirthDate.enable();
      debiturSex.enable();
      debiturAlternateID.enable();

      this.newCertificateForm.patchValue({
        debiturName: '',
        debiturID: '',
        debiturBirthDate: '',
        debiturSex: '',
        debiturAlternateID: ''
      });
    }
  }

  // ─────────────────────────────────────────────────────────
  // DETAIL BUTTONS
  // ─────────────────────────────────────────────────────────

  viewInsuredDetail(): void {
    const clientID =
      this.newCertificateForm.controls.insuredID.value;

    if (!clientID) {
      this.errorMessage.set(
        'Insured ID belum diisi.'
      );
      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  viewDebiturDetail(): void {
    const clientID =
      this.newCertificateForm.controls.debiturID.value;

    if (!clientID) {
      this.errorMessage.set(
        'Debitur ID belum diisi.'
      );
      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  // ─────────────────────────────────────────────────────────
  // AGENT
  // ─────────────────────────────────────────────────────────

  findAgent(): void {
    const agentID =
      this.newCertificateForm.controls.agentID.value;

    if (!agentID) {
      this.errorMessage.set(
        'Masukkan Agent ID terlebih dahulu.'
      );
      return;
    }

    console.log(
      'Find agent:',
      agentID
    );

    // Sambungkan ke endpoint agent search jika tersedia.
  }

  // ─────────────────────────────────────────────────────────
  // NAVIGATION / SUBMIT
  // ─────────────────────────────────────────────────────────

  next(): void {
    this.errorMessage.set('');

    if (this.newCertificateForm.invalid) {
      this.newCertificateForm.markAllAsTouched();

      this.errorMessage.set(
        'Lengkapi field wajib sebelum melanjutkan.'
      );

      return;
    }

    const formValue =
      this.newCertificateForm.getRawValue();

    this.isSubmitting.set(true);

    console.log(
      'New certificate step 1:',
      formValue
    );

    this.isSubmitting.set(false);

    // Contoh navigasi ke step berikutnya:
    //
    // this.router.navigate(
    //   ['/dashboard/certificate/new/coverage'],
    //   {
    //     state: {
    //       certificate: formValue
    //     }
    //   }
    // );
  }

  back(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }

  cancel(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }
}