import { Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ReportsComponent } from './components/reports/reports.component';
import { NewBusinessFormComponent } from './components/new-business-input/new-business-form.component';
import { CertificateListComponent } from './components/certificate-list/certificate-list.component';
import { CertificateDetailComponent } from './components/certificate-detail/certificate-detail.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: 'login',
    component: LoginComponent
  },

  {
    path: 'dashboard',
    component: DashboardComponent,
    children: [
      {
        path: '',
        redirectTo: 'certificate-list',
        pathMatch: 'full'
      },

      {
        path: 'reports',
        component: ReportsComponent
      },

      {
        path: 'reports/:type',
        component: ReportsComponent
      },

      {
        path: 'certificate-list',
        component: CertificateListComponent
      },

      {
        path: 'certificate-detail/:certificateID',
        component: CertificateDetailComponent
      },

      {
        path: 'certificate/new',
        loadComponent: () =>
          import(
            './components/new-certificate/new-certificate.component'
          ).then(
            m => m.NewCertificateComponent
          )
      },

      {
        path: 'client/new',
        loadComponent: () =>
          import(
            './components/new-client/new-client.component'
          ).then(
            m => m.NewClientComponent
          )
      },

      {
        path: 'agent',
        loadComponent: () =>
          import(
            './components/agent/agent.component'
          ).then(
            m => m.AgentComponent
          )
      },

      {
        path: 'new-business-input',
        component: NewBusinessFormComponent
      }
    ]
  },

  {
    path: '**',
    redirectTo: 'login'
  }
];