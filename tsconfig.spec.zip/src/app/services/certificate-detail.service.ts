import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpParams
} from '@angular/common/http';
import {
  Observable,
  map
} from 'rxjs';

import {
  ActivityHistoryItem,
  AgentApiResponse,
  AgentInfo,
  CertificateDetailResponse,
  ClientInfo,
  ClientSearchResult,
  CoverageDocumentInfo,
  HealthQuestionInfo,
  LetterItem,
  PolicyHistoryItem,
  PolicyOption,
  ProductAppliedItem,
  ProductPackageOption
} from '../models/certificate-detail.model';

@Injectable({
  providedIn: 'root'
})
export class CertificateDetailService {
  private readonly http = inject(HttpClient);

  private readonly certificateBaseUrl =
    'https://localhost:7201/api/certificate';

  private readonly agentBaseUrl =
    'https://localhost:7201/api/agents';

  // ============================================================
  // CERTIFICATE DETAIL
  // ============================================================

  getDetail(
    certificateID: string
  ): Observable<CertificateDetailResponse> {
    const id =
      encodeURIComponent(
        certificateID.trim()
      );

    return this.http.get<CertificateDetailResponse>(
      `${this.certificateBaseUrl}/${id}/detail`
    );
  }

  // ============================================================
  // CLIENT DETAIL
  // ============================================================

  getClientInfo(
    clientID: string
  ): Observable<ClientInfo> {
    const id =
      encodeURIComponent(
        clientID.trim()
      );

    return this.http.get<ClientInfo>(
      `${this.certificateBaseUrl}/client/${id}`
    );
  }

  // ============================================================
  // CLIENT SEARCH
  // ============================================================

  searchClients(
    companyID?: string,
    clientName?: string,
    clientID?: string,
    alternateID?: string
  ): Observable<ClientSearchResult[]> {
    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'clientName',
      clientName
    );

    params = this.setOptionalParam(
      params,
      'clientID',
      clientID
    );

    params = this.setOptionalParam(
      params,
      'alternateID',
      alternateID
    );

    return this.http.get<ClientSearchResult[]>(
      `${this.certificateBaseUrl}/client-search`,
      { params }
    );
  }

  // ============================================================
  // AGENT DETAIL
  // ============================================================

  getAgentInfo(
    agentID: string,
    companyID?: string,
    policyID?: string
  ): Observable<AgentInfo> {
    const normalizedAgentID =
      agentID.trim();

    if (!normalizedAgentID) {
      throw new Error(
        'Agent ID wajib diisi untuk detail agent.'
      );
    }

    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'agentID',
      normalizedAgentID
    );

    params = this.setOptionalParam(
      params,
      'policyID',
      policyID
    );

    return this.http.get<AgentApiResponse>(
      `${this.agentBaseUrl}/detail`,
      { params }
    ).pipe(
      map(response => {
        if (
          !response.success ||
          !response.data ||
          response.data.length === 0
        ) {
          throw new Error(
            response.message ||
            'Agent tidak ditemukan.'
          );
        }

        return response.data[0];
      })
    );
  }

  // ============================================================
  // AGENT SEARCH
  // ============================================================

  searchAgents(
    companyID?: string,
    policyID?: string,
    agentID?: string,
    agentName?: string,
    page = 1,
    pageSize = 20
  ): Observable<AgentApiResponse> {
    const normalizedPage =
      Math.max(page, 1);

    const normalizedPageSize =
      Math.min(
        Math.max(pageSize, 1),
        100
      );

    let params = new HttpParams()
      .set(
        'page',
        normalizedPage.toString()
      )
      .set(
        'pageSize',
        normalizedPageSize.toString()
      );

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'policyID',
      policyID
    );

    params = this.setOptionalParam(
      params,
      'agentID',
      agentID
    );

    params = this.setOptionalParam(
      params,
      'agentName',
      agentName
    );

    return this.http.get<AgentApiResponse>(
      `${this.agentBaseUrl}/search`,
      { params }
    );
  }

  // ============================================================
  // POLICY OPTIONS
  // ============================================================

  getPolicyOptions(
    companyID?: string
  ): Observable<PolicyOption[]> {
    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    return this.http.get<PolicyOption[]>(
      `${this.certificateBaseUrl}/policy-options`,
      { params }
    );
  }

  // ============================================================
  // PRODUCT PACKAGE
  // ============================================================

  getProductPackageOptions(
    companyID?: string,
    productPackageID?: string
  ): Observable<ProductPackageOption[]> {
    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'productPackageID',
      productPackageID
    );

    return this.http.get<ProductPackageOption[]>(
      `${this.certificateBaseUrl}/product-package`,
      { params }
    );
  }

  // ============================================================
  // COVERAGE DOCUMENT
  // ============================================================

  getCoverageDocument(
    memberID: string,
    companyID?: string,
    productPackageID?: string
  ): Observable<CoverageDocumentInfo[]> {
    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'productPackageID',
      productPackageID
    );

    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<CoverageDocumentInfo[]>(
      `${this.certificateBaseUrl}/${id}/coverage-document`,
      { params }
    );
  }

  // ============================================================
  // FINANCIAL HEALTH
  // ============================================================

  getFinancialHealth(
    memberID: string,
    companyID?: string,
    productID?: string,
    policyID?: string
  ): Observable<HealthQuestionInfo[]> {
    let params = new HttpParams();

    params = this.setOptionalParam(
      params,
      'companyID',
      companyID
    );

    params = this.setOptionalParam(
      params,
      'productID',
      productID
    );

    params = this.setOptionalParam(
      params,
      'policyID',
      policyID
    );

    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<HealthQuestionInfo[]>(
      `${this.certificateBaseUrl}/${id}/financial-health`,
      { params }
    );
  }

  // ============================================================
  // POLICY HISTORY - PRODUCT APPLIED
  // ============================================================

  getProductApplied(
    memberID: string
  ): Observable<ProductAppliedItem[]> {
    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<ProductAppliedItem[]>(
      `${this.certificateBaseUrl}/${id}/policy-history/product-applied`
    );
  }

  // ============================================================
  // POLICY HISTORY
  // ============================================================

  getPolicyHistory(
    memberID: string
  ): Observable<PolicyHistoryItem[]> {
    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<PolicyHistoryItem[]>(
      `${this.certificateBaseUrl}/${id}/policy-history`
    );
  }

  // ============================================================
  // LETTERS
  // ============================================================

  getLetters(
    memberID: string
  ): Observable<LetterItem[]> {
    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<LetterItem[]>(
      `${this.certificateBaseUrl}/${id}/letters`
    );
  }

  // ============================================================
  // ACTIVITY HISTORY
  // ============================================================

  getActivityHistory(
    memberID: string
  ): Observable<ActivityHistoryItem[]> {
    const id =
      encodeURIComponent(
        memberID.trim()
      );

    return this.http.get<ActivityHistoryItem[]>(
      `${this.certificateBaseUrl}/${id}/activity-history`
    );
  }

  // ============================================================
  // HELPER
  // ============================================================

  private setOptionalParam(
    params: HttpParams,
    name: string,
    value?: string | null
  ): HttpParams {
    if (!value?.trim()) {
      return params;
    }

    return params.set(
      name,
      value.trim()
    );
  }
}