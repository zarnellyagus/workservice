import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule
} from '@angular/forms';
import {
  Router,
  RouterModule
} from '@angular/router';

import {
  AgentInfo
} from '../../models/certificate-detail.model';

import {
  CertificateDetailService
} from '../../services/certificate-detail.service';

@Component({
  selector: 'app-agent',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './agent.component.html',
  styleUrl: './agent.component.css'
})
export class AgentComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  private readonly svc = inject(
    CertificateDetailService
  );

  readonly companyID = 'CP';

  errorMessage = signal('');
  isSearching = signal(false);

  agents = signal<AgentInfo[]>([]);
  selectedAgent = signal<AgentInfo | null>(null);

  currentPage = signal(1);
  pageSize = signal(20);
  totalRows = signal(0);
  totalPages = signal(0);
  hasPreviousPage = signal(false);
  hasNextPage = signal(false);

  searchForm = this.fb.nonNullable.group({
    agentID: [''],
    agentName: ['']
  });

  ngOnInit(): void {
    this.searchAgents();
  }

  back(): void {
    this.router.navigate([
      '/dashboard/certificate/new'
    ]);
  }

  findAgent(): void {
    this.searchAgents();
  }

  searchAgents(): void {
    const agentID =
      this.searchForm.controls.agentID.value.trim();

    const agentName =
      this.searchForm.controls.agentName.value.trim();

    this.isSearching.set(true);
    this.errorMessage.set('');

    this.svc.searchAgents(
      this.companyID,
      '',
      agentID,
      agentName,
      this.currentPage(),
      this.pageSize()
    ).subscribe({
      next: response => {
        this.agents.set(
          response?.data ?? []
        );

        this.totalRows.set(
          response?.pagination?.totalRows ?? 0
        );

        this.totalPages.set(
          response?.pagination?.totalPages ?? 0
        );

        this.hasPreviousPage.set(
          response?.pagination?.hasPreviousPage ?? false
        );

        this.hasNextPage.set(
          response?.pagination?.hasNextPage ?? false
        );

        this.isSearching.set(false);
      },

      error: error => {
        console.error(
          'Search agent error:',
          error
        );

        this.agents.set([]);
        this.totalRows.set(0);
        this.totalPages.set(0);
        this.hasPreviousPage.set(false);
        this.hasNextPage.set(false);
        this.isSearching.set(false);

        this.errorMessage.set(
          error?.error?.message ??
          error?.message ??
          'Gagal mengambil data agent.'
        );
      }
    });
  }

  selectAgent(agent: AgentInfo): void {
    this.selectedAgent.set(agent);

    this.searchForm.patchValue({
      agentID: agent.agentID ?? '',
      agentName: agent.agentName ?? ''
    });
  }

  clear(): void {
    this.searchForm.reset({
      agentID: '',
      agentName: ''
    });

    this.selectedAgent.set(null);
    this.agents.set([]);
    this.currentPage.set(1);
    this.totalRows.set(0);
    this.totalPages.set(0);
    this.hasPreviousPage.set(false);
    this.hasNextPage.set(false);
    this.errorMessage.set('');
  }

  previousPage(): void {
    if (!this.hasPreviousPage()) {
      return;
    }

    this.currentPage.update(
      page => page - 1
    );

    this.searchAgents();
  }

  nextPage(): void {
    if (!this.hasNextPage()) {
      return;
    }

    this.currentPage.update(
      page => page + 1
    );

    this.searchAgents();
  }

  changePageSize(value: string): void {
    const parsedSize =
      Number(value);

    const size =
      Number.isFinite(parsedSize)
        ? Math.min(
            Math.max(parsedSize, 1),
            100
          )
        : 20;

    this.pageSize.set(size);
    this.currentPage.set(1);
    this.searchAgents();
  }

  statusLabel(
    agent: AgentInfo
  ): string {
    return agent.statusage ??
      agent.agentStatus ??
      '';
  }
}