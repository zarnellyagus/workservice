import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  ActivatedRoute,
  Router,
  RouterModule
} from '@angular/router';

import {
  CertificateDetailService
} from '../../services/certificate-detail.service';

import {
  AgentInfo,
  ClientSearchResult,
  PolicyOption
} from '../../models/certificate-detail.model';

@Component({
  selector: 'app-new-certificate',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './new-certificate.component.html',
  styleUrl: './new-certificate.component.css'
})
export class NewCertificateComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly svc = inject(
    CertificateDetailService
  );

  readonly companyID = 'CP';

  isSubmitting = signal(false);
  isLoadingPolicies = signal(false);
  isSearchingClients = signal(false);
  isSearchingAgents = signal(false);

  errorMessage = signal('');

  policyOptions = signal<PolicyOption[]>([]);

  clientSearchResults =
    signal<ClientSearchResult[]>([]);

  agentSearchResults =
    signal<AgentInfo[]>([]);

  isClientSearchOpen = signal(false);
  isAgentSearchOpen = signal(false);

  clientSearchType =
    signal<'insured' | 'debitur'>('insured');

  sexOptions = [
    {
      value: 'M',
      label: 'Male'
    },
    {
      value: 'F',
      label: 'Female'
    }
  ];

  newCertificateForm =
    this.fb.nonNullable.group({
      policyID: [
        '',
        Validators.required
      ],

      ownerName: [''],

      productType: [''],

      insuredName: [
        '',
        Validators.required
      ],

      insuredID: [
        '',
        Validators.required
      ],

      insuredBirthDate: [
        '',
        Validators.required
      ],

      insuredSex: [
        '',
        Validators.required
      ],

      insuredAlternateID: [''],

      insuredAsDebitur: [false],

      debiturName: [
        '',
        Validators.required
      ],

      debiturID: [
        '',
        Validators.required
      ],

      debiturBirthDate: [
        '',
        Validators.required
      ],

      debiturSex: [
        '',
        Validators.required
      ],

      debiturAlternateID: [''],

      /*
       * Agent ID boleh kosong.
       * Jika kosong, tombol lookup membuka list agent.
       * Jika diisi, tombol lookup mengambil detail agent.
       */
      agentID: [''],

      agentName: [''],

      branchName: [''],

      mainBranchName: [''],

      areaName: [''],

      credamName: ['']
    });

  ngOnInit(): void {
    this.loadPolicyOptions();
    this.readQueryParameters();
  }

  private readQueryParameters(): void {
    const policyID =
      this.route.snapshot.queryParamMap.get(
        'policyID'
      );

    if (policyID?.trim()) {
      this.newCertificateForm.controls
        .policyID.setValue(
          policyID.trim()
        );

      this.onPolicyChange();
    }
  }

  loadPolicyOptions(): void {
    this.isLoadingPolicies.set(true);
    this.errorMessage.set('');

    this.svc.getPolicyOptions(
      this.companyID
    ).subscribe({
      next: options => {
        this.policyOptions.set(
          options ?? []
        );

        this.isLoadingPolicies.set(false);
      },

      error: error => {
        console.error(
          'Policy options error:',
          error
        );

        this.policyOptions.set([]);
        this.isLoadingPolicies.set(false);

        this.errorMessage.set(
          'Policy list gagal dimuat.'
        );
      }
    });
  }

  onPolicyChange(): void {
    const policyID =
      this.newCertificateForm.controls
        .policyID.value.trim();

    const selectedPolicy =
      this.policyOptions().find(
        policy =>
          policy.policyID === policyID
      );

    this.newCertificateForm.patchValue({
      ownerName:
        selectedPolicy?.policyOwnerName ?? '',

      productType:
        selectedPolicy?.productTypeName ?? ''
    });
  }

  findInsuredClient(): void {
    const controls =
      this.newCertificateForm.controls;

    this.searchClient(
      'insured',
      controls.insuredName.value,
      controls.insuredID.value,
      controls.insuredAlternateID.value
    );
  }

  findDebiturClient(): void {
    const controls =
      this.newCertificateForm.controls;

    this.searchClient(
      'debitur',
      controls.debiturName.value,
      controls.debiturID.value,
      controls.debiturAlternateID.value
    );
  }

  private searchClient(
    type: 'insured' | 'debitur',
    clientName: string,
    clientID: string,
    alternateID: string
  ): void {
    const hasSearchValue =
      clientName.trim() ||
      clientID.trim() ||
      alternateID.trim();

    if (!hasSearchValue) {
      this.errorMessage.set(
        type === 'insured'
          ? 'Isi Insured Name, Insured ID, atau Alternate ID.'
          : 'Isi Debitur Name, Debitur ID, atau Alternate ID.'
      );

      return;
    }

    this.errorMessage.set('');
    this.clientSearchType.set(type);
    this.clientSearchResults.set([]);
    this.isClientSearchOpen.set(true);
    this.isSearchingClients.set(true);

    this.svc.searchClients(
      this.companyID,
      clientName,
      clientID,
      alternateID
    ).subscribe({
      next: results => {
        this.clientSearchResults.set(
          results ?? []
        );

        this.isSearchingClients.set(false);
      },

      error: error => {
        console.error(
          'Client search error:',
          error
        );

        this.clientSearchResults.set([]);
        this.isSearchingClients.set(false);

        this.errorMessage.set(
          error?.error?.message ??
          'Pencarian client gagal.'
        );
      }
    });
  }

  selectClient(
    client: ClientSearchResult
  ): void {
    const type =
      this.clientSearchType();

    const clientName =
      client.clientName ?? '';

    const clientID =
      client.clientID ?? '';

    const alternateID =
      client.alternateID ?? '';

    const birthDate =
      this.toDateInput(
        client.birthDate
      );

    const sex =
      client.sex ?? '';

    if (type === 'insured') {
      this.newCertificateForm.patchValue({
        insuredName: clientName,
        insuredID: clientID,
        insuredAlternateID: alternateID,
        insuredBirthDate: birthDate,
        insuredSex: sex
      });
    } else {
      this.newCertificateForm.patchValue({
        debiturName: clientName,
        debiturID: clientID,
        debiturAlternateID: alternateID,
        debiturBirthDate: birthDate,
        debiturSex: sex
      });
    }

    this.closeClientSearch();
  }

  closeClientSearch(): void {
    this.isClientSearchOpen.set(false);
    this.isSearchingClients.set(false);
    this.clientSearchResults.set([]);
  }

  newClient(): void {
    const type =
      this.clientSearchType();

    this.closeClientSearch();

    this.router.navigate(
      ['/dashboard/client/new'],
      {
        queryParams: {
          type,
          companyID: this.companyID
        }
      }
    );
  }

  private toDateInput(
    value?: string | null
  ): string {
    if (!value) {
      return '';
    }

    return value.substring(0, 10);
  }

  onInsuredAsDebiturChange(): void {
    const controls =
      this.newCertificateForm.controls;

    const checked =
      controls.insuredAsDebitur.value;

    if (checked) {
      const insured =
        this.newCertificateForm.getRawValue();

      this.newCertificateForm.patchValue({
        debiturName:
          insured.insuredName,

        debiturID:
          insured.insuredID,

        debiturBirthDate:
          insured.insuredBirthDate,

        debiturSex:
          insured.insuredSex,

        debiturAlternateID:
          insured.insuredAlternateID
      });

      controls.debiturName.disable();
      controls.debiturID.disable();
      controls.debiturBirthDate.disable();
      controls.debiturSex.disable();
      controls.debiturAlternateID.disable();
    } else {
      controls.debiturName.enable();
      controls.debiturID.enable();
      controls.debiturBirthDate.enable();
      controls.debiturSex.enable();
      controls.debiturAlternateID.enable();

      this.newCertificateForm.patchValue({
        debiturName: '',
        debiturID: '',
        debiturBirthDate: '',
        debiturSex: '',
        debiturAlternateID: ''
      });
    }
  }

  viewInsuredDetail(): void {
    const clientID =
      this.newCertificateForm.controls
        .insuredID.value.trim();

    if (!clientID) {
      this.errorMessage.set(
        'Insured ID belum diisi.'
      );

      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  viewDebiturDetail(): void {
    const clientID =
      this.newCertificateForm.controls
        .debiturID.value.trim();

    if (!clientID) {
      this.errorMessage.set(
        'Debitur ID belum diisi.'
      );

      return;
    }

    this.router.navigate([
      '/dashboard/client',
      clientID
    ]);
  }

  findAgent(): void {
    const controls =
      this.newCertificateForm.controls;

    const agentID =
      controls.agentID.value.trim();

    const policyID =
      controls.policyID.value.trim();

    this.errorMessage.set('');

    /*
     * Jika Agent ID kosong, buka list agent.
     */
    if (!agentID) {
      this.openAgentSearch();
      return;
    }

    this.isSubmitting.set(true);

    this.svc.getAgentInfo(
      agentID,
      this.companyID,
      policyID
    ).subscribe({
      next: agent => {
        this.patchAgentToForm(
          agent,
          agentID
        );

        this.isSubmitting.set(false);
      },

      error: error => {
        console.error(
          'Get agent error:',
          error
        );

        this.clearAgentFields();
        this.isSubmitting.set(false);

        this.errorMessage.set(
          error?.error?.message ??
          error?.message ??
          'Data agent tidak ditemukan.'
        );
      }
    });
  }
openAgentPage(): void {
  this.router.navigate([
    '/dashboard/agent'
  ]);
}
  openAgentSearch(): void {
    const policyID =
      this.newCertificateForm.controls
        .policyID.value.trim();

    this.errorMessage.set('');
    this.agentSearchResults.set([]);
    this.isAgentSearchOpen.set(true);
    this.isSearchingAgents.set(true);

    this.svc.searchAgents(
      this.companyID,
      policyID,
      '',
      '',
      1,
      20
    ).subscribe({
      next: response => {
        this.agentSearchResults.set(
          response?.data ?? []
        );

        this.isSearchingAgents.set(false);
      },

      error: error => {
        console.error(
          'Search agent error:',
          error
        );

        this.agentSearchResults.set([]);
        this.isSearchingAgents.set(false);

        this.errorMessage.set(
          error?.error?.message ??
          'Daftar agent gagal dimuat.'
        );
      }
    });
  }

  selectAgent(
    agent: AgentInfo
  ): void {
    this.patchAgentToForm(
      agent,
      agent.agentID ?? ''
    );

    this.closeAgentSearch();
  }

  closeAgentSearch(): void {
    this.isAgentSearchOpen.set(false);
    this.isSearchingAgents.set(false);
    this.agentSearchResults.set([]);
  }

  private patchAgentToForm(
    agent: AgentInfo,
    fallbackAgentID = ''
  ): void {
    this.newCertificateForm.patchValue({
      agentID:
        agent.agentID ??
        fallbackAgentID,

      agentName:
        agent.agentName ?? '',

      branchName:
        agent.branchName ?? '',

      mainBranchName:
        agent.mainBranchName ?? '',

      areaName:
        agent.areaName ?? '',

      /*
       * Backend memakai crudanName.
       * Form masih memakai credamName.
       */
      credamName:
        agent.credamName ?? ''
    });
  }

  private clearAgentFields(): void {
    this.newCertificateForm.patchValue({
      agentName: '',
      branchName: '',
      mainBranchName: '',
      areaName: '',
      credamName: ''
    });
  }

  next(): void {
    this.errorMessage.set('');

    if (this.newCertificateForm.invalid) {
      this.newCertificateForm.markAllAsTouched();

      this.errorMessage.set(
        'Lengkapi field wajib sebelum melanjutkan.'
      );

      return;
    }

    const payload =
      this.newCertificateForm.getRawValue();

    console.log(
      'New certificate payload:',
      payload
    );

    this.isSubmitting.set(true);

    /*
     * Hubungkan ke API create certificate di sini.
     *
     * Contoh:
     *
     * this.svc.createCertificate(payload)
     *   .subscribe({
     *     next: () => {
     *       this.isSubmitting.set(false);
     *       this.router.navigate([
     *         '/dashboard/certificate-list'
     *       ]);
     *     },
     *     error: error => {
     *       this.isSubmitting.set(false);
     *       this.errorMessage.set(
     *         error?.error?.message ??
     *         'Gagal membuat certificate.'
     *       );
     *     }
     *   });
     */

    this.isSubmitting.set(false);
  }

  back(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }

  cancel(): void {
    this.router.navigate([
      '/dashboard/certificate-list'
    ]);
  }
}