export interface Agent {
  policyID: string;
  companyID: string;
  agentID: string;
  agentName: string;
  agentEffDate?: string | null;
  agentStatus: string;
  homePhone?: string | null;
  createdBy?: string | null;
  createdDate?: string | null;
  updatedBy?: string | null;
  updatedDate?: string | null;
  branchID?: string | null;
  branchName?: string | null;
  mainBranchID?: string | null;
  mainBranchName?: string | null;
  areaID?: string | null;
  areaName?: string | null;
  credamID?: string | null;
  credamName?: string | null;
  statusage?: string | null;
}

export interface AgentSearchParams {
  companyID: string;
  policyID?: string;
  agentID?: string;
  agentName?: string;
}